public class Tile {
    private int x, y, type;
    private float humidity, fuel, wind;

    //Constructor
    public Tile(int x, int y, int type, float humidity, float fuel) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.humidity = humidity;
        this.fuel = fuel;
        this.wind = 0;
    }

    //Getters
    public int getX() { return x; }
    public int getY() { return y; }
    public int getType() { return type; }
    public float getFuel() { return fuel; }
    public float getHumidity() { return humidity; }
    public float getWind() { return wind; }

    //Setters
    public void setType(int type) { this.type = type; } // Corrigido: Setter para o tipo
    public void setFuel(float fuel) { this.fuel = fuel; }
    public void setHumidity(float humidity) { this.humidity = humidity; }
    public void setWind(float wind) { this.wind = wind; }

    @Override
    public String toString() {
        return "Tile(" + x + "," + y + ") - Type: " + type + ",  Humidity: " + humidity + ", Fuel: " + fuel + "\n";
    }
}