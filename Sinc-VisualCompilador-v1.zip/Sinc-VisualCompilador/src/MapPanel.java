import javax.swing.*;
import java.awt.*;

public class MapPanel extends JPanel {
    private Map map;
    private static final int TILE_VISUAL_SIZE = 40; // Tamanho visual de cada Tile em pixels

    public MapPanel(Map map) {
        this.map = map;
        // Define o tamanho preferencial do painel baseado nas dimensões do mapa
        int panelWidth = Map.WIDTH * TILE_VISUAL_SIZE;
        int panelHeight = Map.HEIGHT * TILE_VISUAL_SIZE + 25; // + 25 para que o contador fique abaixo do mapa
        setPreferredSize(new Dimension(panelWidth, panelHeight));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Limpa o painel

        // Desenha cada Tile
        for (int x = 0; x < Map.WIDTH; x++) {
            for (int y = 0; y < Map.HEIGHT; y++) {
                Tile tile = map.getTile(x, y);
                if (tile != null) {
                    // Define a cor do Tile baseado no seu tipo
                    g.setColor(getColorForType(tile.getType()));
                    // Desenha o Tile como um retângulo preenchido
                    g.fillRect(x * TILE_VISUAL_SIZE, y * TILE_VISUAL_SIZE, TILE_VISUAL_SIZE, TILE_VISUAL_SIZE);

                    // Desenha uma borda para cada Tile (TODO: Deixar a borda?)
                    g.setColor(Color.BLACK);
                    g.drawRect(x * TILE_VISUAL_SIZE, y * TILE_VISUAL_SIZE, TILE_VISUAL_SIZE, TILE_VISUAL_SIZE);
                }
            }
        }

        // Exibe o contador
        g.setColor(Color.DARK_GRAY);
        g.setFont(new Font("Arial", Font.BOLD, 14));
        String countText = "Update count: " + map.getCounter();
        // Posiciona o contador no canto inferior esquerdo (com uma pequena margem)
        FontMetrics fm = g.getFontMetrics();
        g.drawString(countText, 5, getHeight() - fm.getDescent() - 5);
    }

    private Color getColorForType(int type) {
        switch (type) {
            case 1: return new Color(30, 144, 255); // DodgerBlue
            case 2: return new Color(50, 205, 50);  // LimeGreen
            case 3: return new Color(255, 255, 0); // Yellow
            case 4: return new Color(255, 165, 0); // Orange
            case 5: return new Color(255, 69, 0);   // OrangeRed
            default: return Color.LIGHT_GRAY;      // Cor padrão para tipos desconhecidos
        }
    }
}