public class Map {
    public static final int WIDTH = 10;
    public static final int HEIGHT = 10;
    private Tile[][] tiles = new Tile[WIDTH][HEIGHT];
    public int counter = -1;

    public Map() {
        mapStart();
    }

    private void mapStart() {
        for (int x = 0; x < WIDTH; x++) {
            for (int y = 0; y < HEIGHT; y++) {
                int type = (int) (Math.random() * 5) + 1;
                float fuel = type * 1000;
                int humidity = type + (int) (Math.random() * type * 2);
                tiles[x][y] = new Tile(x, y, type, humidity, fuel);
            }
        }
    }

    // Metodo de exemplo para alterar dinamicamente um Tile (TODO: Deixar o agente realizar isso)
    public void changeRandomTileType() {
        if (WIDTH > 0 && HEIGHT > 0) {
            int x = (int) (Math.random() * WIDTH);
            int y = (int) (Math.random() * HEIGHT);
            int newType = (int) (Math.random() * 5) + 1;
            float newFuel = newType * 1000;
            int newHumidity = newType + (int) (Math.random() * newType * 2);
            if (tiles[x][y] != null) {
                tiles[x][y].setType(newType);
                tiles[x][y].setFuel(newFuel);
                tiles[x][y].setHumidity(newHumidity);
            }
        }
    }

    public Tile getTile(int x, int y) {
        if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
            return tiles[x][y];
        }
        return null;
    }

    public int getCounter() {
        return counter;
    }
}