import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        Map map = new Map();

        // Executa a criação da GUI na Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Mapa");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            MapPanel mapPanel = new MapPanel(map);
            frame.add(mapPanel);

            frame.pack(); // Ajusta o tamanho da janela ao conteúdo
            frame.setLocationRelativeTo(null); // Centraliza a janela na tela
            frame.setVisible(true);

            // Timer para atualizar a visualização a cada segundo (1000 ms)
            Timer timer = new Timer(1000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // TODO: Deixar o agente realizar isso
                    // 1. Lógica para alterar os atributos dos Tiles dinamicamente
                    map.changeRandomTileType();

                    // 2. Incrementar o contador
                    map.counter++;

                    // 3. Fazer update do MapPanel
                    mapPanel.repaint();
                }
            });
            timer.start(); // Inicia o timer
        });
    }
}